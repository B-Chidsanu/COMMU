﻿namespace FoodPenguinAPI.Models
{
    public class FoodModel
    {
        public int food_id { get; set; }
        public string name { get; set; }
        public string amount { get; set; }
    }
}
