﻿namespace FoodPenguinAPI.Models
{
    public class MarketModel
    {
        public int market_id { get; set; }
        public string name { get; set; }
    }
}
