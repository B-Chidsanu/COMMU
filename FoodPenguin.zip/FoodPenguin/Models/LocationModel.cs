﻿namespace FoodPenguinAPI.Models
{
    public class LocationModel
    {
        public int loc_id { get; set; }
        public string name { get; set; }
    }
}
